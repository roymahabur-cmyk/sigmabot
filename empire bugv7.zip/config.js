module.exports = {
    // Telegram Bot Token
    mainToken: '8800737237:AAHyFf8XPhwj4H30_3T52553Eym3RZJSnlY',

    // Developer Info
    S7: '@SigmaVip7x',

    // Admin Telegram ID
    adminId: 8900848320,

    // Telegram Links
    channel:  'https://t.me/vipsigma777x',
    schannel: 'https://t.me/vipsigma777x',
    group:    'https://t.me/vipsigma77x',

    // Social Links
    youtube:   'https://t.me/vipsigma777x',
    waChannel: 'https://t.me/vipsigma777x',
    instagram: 'https://t.me/vipsigma777x',

    // Channel / Group IDs (bot must be admin)
    channelId:  '-1004331089193',
    schannelId: '-1004331089193',
    groupId:    '-1004331089193',

    // Bot Display Name
    bot: '𝗦𝗜𝗚𝗠𝗔 𝗕𝗨𝗚 𝗕𝗢𝗧',

    // Logo path
    logo: './SY/Loves.jpg',

    // ══════════════════════════════════════════════════════
    //  PROXY LIST
    //  Each WhatsApp session gets its own proxy IP.
    //  Different IPs = WhatsApp cannot detect all bug
    //  messages come from one server → less throttling.
    //
    //  Formats:
    //    'socks5://user:pass@ip:port'
    //    'socks5://ip:port'
    //    'socks4://ip:port'
    //    'http://user:pass@ip:port'
    //    'http://ip:port'
    //
    //  Leave [] to run without proxy.
    //
    //  Free SOCKS5 proxies:
    //    https://www.proxy-list.download/SOCKS5
    //    https://spys.one/free-proxy-list/
    // ══════════════════════════════════════════════════════
    proxies: [
        // 'socks5://123.45.67.89:1080',
        // 'socks5://user:pass@111.22.33.44:1080',
        // 'http://111.22.33.44:8080',
    ],
};
